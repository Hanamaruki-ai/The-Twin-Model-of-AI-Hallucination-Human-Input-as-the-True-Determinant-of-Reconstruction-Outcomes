MT License (Machine Teaching License)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this theory, documentation, or associated files (the “Work”), to use,
study, reproduce, and modify the Work for non-commercial AI research,
teaching-design development, or model-alignment purposes.

Commercial use, redistribution for monetary gain, or integration into
proprietary AI systems requires explicit written permission from the author.

The Work is provided “as-is”, without warranty of any kind, including but
not limited to correctness, safety, or fitness for purpose.

© 2025 Hanamaruki
